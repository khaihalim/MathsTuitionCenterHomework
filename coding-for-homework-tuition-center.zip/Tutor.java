public class Tutor{
    String name;
    int IC;
    String address;
    String qualification;
    int yearExp;
    String date;
    int year;
}