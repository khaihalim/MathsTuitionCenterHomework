public class CenterList{
    TuitionCenter CenterList[]=new TuitionCenter[5];
    int currentCenter=0;
    
    void addCenter(Center b){
        Centerlist[currentCenter++]=b;
    }
    void deleteCenter(Center b){
        for(int i=0;i<5;i++){
            if Centerlist[i]==b{
                Centerlist[i]==null;
                System.out.print("The center has been deleted");
            }
        }
    }
}