
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    
	    Tutor Ramli=new Tutor();
	    Ramli.name="Ramli";
	    Ramli.IC="2200";
	    Ramli.address="Selangor";
	    Ramli.qualification="Degree";
	    Ramli.yearExp=3;
	    Ramli.date="04/01/2021";
	    Ramli.year=5;
	    
	    Tutor Minah=new Tutor();
	    Minah.name="Minah";
	    Minah.IC="2876";
	    Minah.address="Selangor";
	    Minah.qualification="Degree";
	    Minah.yearExp=8;
	    Minah.date="04/05/2015";
	    Minah.year=10;
	    
	    Student Razak=new Student();
	    Razak.name="Razak";
	    Razal.IC="2345";
	    Razak.address="Melaka";
	    Razak.addScore();
	    Razak.assignTutor(Minah);
	    
	    Student Mimi=new Student();
	    Mimi.name="Mimi";
	    Mimi.IC="5510";
	    Mimi.address="Pahang";
	    Mimi.addScore();
	    Mimi.assignTutor(Ramli);
	    
	    
		
	}
}
